package org.example.model.queryProcessor;

record WithClause(String left, String right) {}
